'use strict';

/**
 * @ngdoc function
 * @name partnerApp.controller:CustomerCtrl
 * @description
 * # CustomerCtrl
 * Controller of the partnerApp
 */
angular.module('partnerApp')
  .controller('CustomerCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
